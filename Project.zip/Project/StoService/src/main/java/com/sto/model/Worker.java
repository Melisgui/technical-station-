package com.sto.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.ColumnDefault;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.util.LinkedHashSet;
import java.util.Set;

@Getter
@Setter
@Entity
@Table(name = "worker", schema = "public")
public class Worker {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "worker_id_gen")
    @SequenceGenerator(name = "worker_id_gen", sequenceName = "worker_user_id_seq", allocationSize = 1)
    @Column(name = "user_id", nullable = false)
    private Integer id;

    @MapsId
    @OneToOne(fetch = FetchType.LAZY, optional = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    @ColumnDefault("nextval('worker_user_id_seq')")
    @JoinColumn(name = "user_id", nullable = false)
    private User users;

    @Size(max = 100)
    @Column(name = "specialization", length = 100)
    private String specialization;

    @Column(name = "experience_years")
    private Integer experienceYears;

    @Size(max = 50)
    @Column(name = "verification_code", length = 50)
    private String verificationCode;

    @ManyToOne(fetch = FetchType.LAZY)
    @OnDelete(action = OnDeleteAction.SET_NULL)
    @JoinColumn(name = "sto_id")
    private Sto sto;

    @OneToMany(mappedBy = "worker")
    private Set<WorkerReview> workerReviews = new LinkedHashSet<>();

}