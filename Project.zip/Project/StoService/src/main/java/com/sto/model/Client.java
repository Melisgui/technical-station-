package com.sto.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.ColumnDefault;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import java.util.LinkedHashSet;
import java.util.Set;

@Getter
@Setter
@Entity
@Table(name = "client", schema = "public")
public class Client {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "client_id_gen")
    @SequenceGenerator(name = "client_id_gen", sequenceName = "client_user_id_seq", allocationSize = 1)
    @Column(name = "user_id", nullable = false)
    private Integer id;

    @MapsId
    @OneToOne(fetch = FetchType.LAZY, optional = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
    @ColumnDefault("nextval('client_user_id_seq')")
    @JoinColumn(name = "user_id", nullable = false)
    private User users;

    @Size(max = 20)
    @Column(name = "car_brand", length = 20)
    private String carBrand;

    @Size(max = 40)
    @Column(name = "car_model", length = 40)
    private String carModel;

    @Column(name = "car_year")
    private Integer carYear;

    @OneToMany(mappedBy = "client")
    private Set<Appointment> appointments = new LinkedHashSet<>();

    @OneToMany(mappedBy = "client")
    private Set<Car> cars = new LinkedHashSet<>();

    @OneToMany(mappedBy = "client")
    private Set<ClientReview> clientReviews = new LinkedHashSet<>();

}